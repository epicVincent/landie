<?php

namespace App\Http\Controllers;

use PDF;
use App\Transaction;
use DateTime;
use App\House;
use App\Tenant;
use Illuminate\Http\Request;

class TenantController extends Controller
{
  /**
   * Create a new controller instance.
   *
   * @return void
   */




  public function __construct()
  {
      $this->middleware('auth');
  }


    // get a summary of all tenants with a balance
    public function balance(){

    }

    public function sendMessage(Request $request){
        //use the request body as the message 
        //and an array of numbers to send to 
    $nexmo = app('Nexmo\Client');
        $message = $request->message;
        $contacts = $request->contacts;

        // var_dump($contacts);

        for($i=0; $i < count($contacts); $i++){
            //run nexmo code to send the message
            // echo $contacts[0];
            $nexmo->message()->send([
                'to'   => $contacts[$i],
                'from' => '254719546525',
                'text' => $message,
             ]);
            
        }
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index()
    {
        //
        $tenants = Tenant::paginate(15);
        $rooms = House::all();

        $tenantids = ['33200000','43222987','23045600','16340000','432909043','34224356465','324535212'];

        // find tenants with rent alias
        $defaulters = Tenant::where('paid', '=<', 'balance')->get();

        $kra = ['KLJA2342','23GQFDS','233T64GE','TW324343','23R5SD'];

        $defaults_number = $defaulters->count();


        return view('landlord.partials.home',compact('tenants','rooms','defaults_number','tenantids','kra'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $tenant = new Tenant();
        $tenant->username = $request->username;
        $tenant->email = $request->email;
        $tenant->house_id= $request->roomnumber;
        $tenant->contact = $request->contact;
        $tenant->National_id= $request->national_id;
        $tenant->KRA_PIN= $request->kra_pin;

        $tenant->save();

        return redirect()->route('getTenants');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Tenant  $tenant
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
        //

        $defaulters = Tenant::where('paid', '=<', 'balance')->get();

        // var_dump($defaulters);

        return view('landlord.partials.debtors',compact('defaulters'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Tenant  $tenant
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $tenant = Tenant::findOrFail($id);

        $rooms = House::all();
        return view('landlord.partials.editTenant',compact('tenant','rooms'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Tenant  $tenant
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Tenant $tenant)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Tenant  $tenant
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $tenant = Tenant::findOrFail($id);
        $tenant->delete();

        return redirect()->route('homepage');
    }

   //  function to return the number of months a tenant have
   // been in a house, the rent expected for that period and the rent
   // that have been paid upto the present date

   public function refresh($tenant_id){
     // calculate the differnce in months between entry month
     // and current month
     $tenant_history = Tenant::findOrFail($tenant_id);

     //find the details of the house the tenant have ranted
     $house = House::findOrFail($tenant_history->house_id);



     $entry_month = $tenant_history->created_at;
     $current_month = new DateTime();

     $interval = $entry_month->diff($current_month);

     $months_occupied = $interval->m;

     if($months_occupied == 0)
     {
       // for the first month add 1
       $months_occupied = $months_occupied+1;
     }else{
       $months_occupied = $months_occupied;
     }


     //take a total of the rent paid to his account
     $rent_paid = $tenant_history->paid;
     //take the expected rent for the house and multiply it by the months difference
     $rent_payable = $house->rent * $months_occupied;


     //take the difference in rents to find the balance
     $rent_balance = $rent_payable - $rent_paid;

     // update his database on his transaction

     $tenant_history->paid = $tenant_history->paid;
     $tenant_history->balance = $rent_balance;

     $tenant_history->save();

     return redirect()->route('homepage');

   }

   public function RentAlias(){
       //find from the database a list of all the people who have a balance
       $tenant_alias = [];

       $tenants = Tenant::all();


   }


    public function generatePDF() {

      $tenants = Tenant::paginate(15);
      $rooms = House::all();

      $tenantids = ['33200000','43222987','23045600','16340000','432909043','34224356465','324535212'];

      // find tenants with rent alias
      $defaulters = Tenant::where('paid', '=<', 'balance')->get();
      $cleared = Tenant::where('paid','>','balance')->get();

      $kra = ['KLJA2342','23GQFDS','233T64GE','TW324343','23R5SD'];

      $defaults_number = $defaulters->count();

      $data = [
        'defaulter' => $defaulters,
        'cleared' => $cleared,
        'picture' => 'some image hre',
        'securitycode' => 'user hashed name and mpesa payment and expiry date',
        'businessinfo' => 'data about the business'
      ];
       // Send data to the view using loadView function of PDF facade
      $pdf = PDF::loadView('landlord.report',['data'=>$data]);
      //var_dump($data);
      // Finally, you can download the file using download function
     return $pdf->download('permit.pdf');

    }

    public function tenantActivities($id){
        $tenant = Tenant::where('id','=',$id)->first();
        $transactions = Transaction::where('tenant_id','=',$id)->paginate(40);

        // var_dump($transactions);


      $data = [
        'tenant' => $tenant,
        'transactions' => $transactions,
        'picture' => 'some image hre',
        'securitycode' => 'user hashed name and mpesa payment and expiry date',
        'businessinfo' => 'data about the business'
      ];
       // Send data to the view using loadView function of PDF facade
      $pdf = PDF::loadView('landlord.tenantreport',['data'=>$data]);
      //var_dump($data);
      // Finally, you can download the file using download function
     return $pdf->download('tenantreport.pdf');
    }
}
