<?php

namespace App\Http\Controllers;

use DB;
use App\Tenant;
use Carbon\Carbon;
use App\Transaction;
use App\Mail\PaymentMade;
use Illuminate\Support\Facades\Mail;
use Illuminate\Http\Request;

class TransactionController extends Controller
{
  //
  // each mpesa transaction should be related to a certain tenant
  // throught their contact number
  public function getContact($contact){
    //get the bill ref number from the mpesa response to fetch a tenants data

    return $tenant_id;
  }

  public function index(){
    $transactions = Transaction::paginate(50);
    //find the total rent paid for a month and for all the time
    $total_rent_paid = Transaction::sum('amount');

    return view('landlord.partials.transactions',compact('transactions','total_rent_paid'));
  }

  public function validateTransaction(Request $request){

    // confirm that the account number (tenant's contact exists in the database
   $invoice = DB::table('tenants')->where('contact','=',$request->get('BillRefNumber'))->first() ;
   $tenant_contact = $invoice->contact;

    if($tenant_contact == '' || $tenant_contact != $request->get('BillRefNumber'))
    {
      return $this->invalidResponse();
    }

    return $this->successfulResponse();
  }

  public function confirmTransaction(Request $request){

    $transact = $this->createTransaction($request);

    return $this->successfulResponse();
  }


  /**
 * Create a new mpesa transaction
 *
 * @param Request $request
 * @param Invoice $invoice
 * @param int     $status
 *
 * @return Transaction
 */
protected function createTransaction(Request $request)
{

  //relate a transaction to a certain user, i.e the one of the contact used as
  //billrefnumber
  $tenant = DB::table('tenants')->where('contact','=',$request->get('BillRefNumber'))->first();
  $tenant_id = $tenant->id;

  if($tenant_id != ''){
    $tenant_data = Tenant::findOrFail($tenant_id);
    $tenant_data->paid = $tenant_data->paid + $request->get('TransAmount');
    $tenant_data->save();
  }


  $nexmo = app('Nexmo\Client');
    
    $nexmo->message()->send([
        'to'   => $request->get('BillRefNumber'),
        'from' => '254719546525',
        'text' => 'CONFIRMED YOUR PAYMENT OF RENT OF AMMOUNT: '.$request->get('TransAmount'). 'A RECEIPT WILL BE E-MAILED TO YOU SHORTLY' ,
    ]);

    $nexmo->message()->send([
        'to'   => '254715404205',
        'from' => '254719546525',
        'text' => 'Rent payment received '.$request->get('TransAmount').' by '.$request->get('MSISDN').' from '.$tenant->username. ' Time '.$request->get('TransTime'), 
   ]);

  //send an email to the tenant indicating receipt of Payment
  $content = [
      'title' => 'Payment of rent received from '.$tenant_data->username,
      'body' => 'You have rent amount ='.$request->get('TransAmount'),
     ];

     $recipientAddress  = $tenant->email;

    if($tenant->email != ''){
      Mail::to($recipientAddress)->send(new PaymentMade($content));
    }


    return Transaction::create([
        'tenant_id' => $tenant_id,
        'transaction_time' => Carbon::parse($request->get('TransTime', null)),
        'transaction_number' => $request->get('TransID'),
        'amount' => $request->get('TransAmount'),
        'short_code' => $request->get('BusinessShortCode'),
        'bill_reference' => $request->get('BillRefNumber'),
        'mobile_number' => $request->get('MSISDN'),
        'payer_first_name' => $request->get('FirstName'),
        'payer_middle_name' => $request->get('MiddleName'),
        'payer_last_name' => $request->get('LastName'),
        'status' => 1,
    ]);
}

  // send a sucessful mpesa response to validate and confirm

  protected function successfulResponse(){
    return response()->json([
      'ResultCode'=> 0,
      'ResultDesc'=>'Transaction completed successfully',
      'ThirdPartyTransID' => 1
    ]);

  }

  // send a bad request to safaricom api

  protected function invalidResponse(){
    return response()->json([
      'ResultCode' => 1,
      'ResultDesc' => 'Failed to complete the transaction',
      'ThirdPartyTransID' => 0
    ]);
  }

}
