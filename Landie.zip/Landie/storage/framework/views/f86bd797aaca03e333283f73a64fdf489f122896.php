<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Tenants with rent arrears</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>Tenant Name</th>
                  <th>Amount Paid</th>
                  <th>Remaining Balance</th>
                  <th>Month last paid</th>

                </tr>
                </thead>
                <tbody>

                </tbody>
                <tfoot>

                <?php $__currentLoopData = $defaulters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $defaulter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>

                <td><?php echo e($defaulter->username); ?></td>
                <td><?php echo e($defaulter->paid); ?></td>
                <td><?php echo e($defaulter->balance); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($defaulter->updated_at)->format('d/m/Y')); ?></td>
                

              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <!-- <tr>
                <th>Rendering engine</th>
                <th>Browser</th>
                <th>Platform(s)</th>
                <th>Engine version</th>
                <th>CSS grade</th>
              </tr> -->
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('landlord.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>