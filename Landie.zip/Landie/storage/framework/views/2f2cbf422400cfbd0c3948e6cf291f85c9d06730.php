<?php $__env->startSection('content'); ?>
<div class="row">

  <div class="col-lg-3 col-xs-6">
    <!-- small box -->
    <div class="small-box bg-green">
      <div class="inner">
        <h3><?php echo e($total_rent_paid); ?></h3>

        <p>Total Paid</p>
      </div>
      <div class="icon">
        <i class="ion ion-stats-bars"></i>
      </div>
      
    </div>
  </div>

</div>


<div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Hover Data Table</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>Transaction Number</th>
                  <th>Contact</th>

                  <th>Time</th>
                  <th>Amount</th>
                  <th>FirstName</th>
                </tr>
                </thead>
                <tbody>

                </tbody>
                <tfoot>
              <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($transaction->transaction_number); ?></td>
                <td><?php echo e($transaction->bill_reference); ?></td>
                <td><?php echo e($transaction->transaction_time); ?></td>
                <td><?php echo e($transaction->amount); ?></td>
                <td><?php echo e($transaction->payer_first_name); ?></td>

              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <!-- <tr>
                <th>Rendering engine</th>
                <th>Browser</th>
                <th>Platform(s)</th>
                <th>Engine version</th>
                <th>CSS grade</th>
              </tr> -->
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('landlord.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>