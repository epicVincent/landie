<html>
<head></head>
<body style="background: black; color: white">
<h1><?php echo e($amount); ?></h1>
<p><?php echo e($time); ?></p>
</body>
</html>
