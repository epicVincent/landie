<?php $__env->startSection('styles'); ?>

  <style>
  .example-modal .modal {
    position: relative;
    top: auto;
    bottom: auto;
    right: auto;
    left: auto;
    display: block;
    z-index: 1;
  }

  .example-modal .modal {
    background: transparent !important;
  }
</style>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-lg-3 col-xs-6">
  <!-- small box -->
  <div class="small-box bg-red">
    <div class="inner">
      <h3><?php echo e($defaults_number); ?></h3>

      <p>Tenants with rent alias</p>
    </div>
    <div class="icon">
      <i class="ion ion-pie-graph"></i>
    </div>
     <a href="<?php echo e(route('unpaid')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
  </div>

  <div class="">
    <a href="<?php echo e(route('report')); ?>" class="btn btn-info"  name="button">Genereate Report</a>
  </div>
</div>
</div>

<div class="row">
  <div class="col-md-8">

  <!-- PRODUCT LIST -->
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Tenants</h3>

            <div class="box-tools pull-right">
              <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
              </button>
              <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
            </div>
          </div>
          <!-- /.box-header -->
          <div class="box-body">

            <ul class="products-list product-list-in-box">
          <?php $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$tenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="item">
                <div class="product-img">
                  <img src="dist/img/default-50x50.gif" alt="Product Image">
                </div>
                <div class="product-info">
                  <a href="javascript:void(0)" class="product-title"><?php echo e($tenant->username); ?>

                    <span class="label label-warning pull-right"><?php echo e($tenant->contact); ?></span></a>
                  <span class="product-description">
                  <p class="text-blue">Room number:   <?php echo e($tenant->house_id); ?></p>
                      
                      </span>
                </div>
                <div class="product-info">

                  <p class="text-blue">National Id:   <?php echo e($tenant->National_id); ?></p>
                    <p class="text-blue">KRA pin:   <?php echo e($tenant->KRA_PIN); ?></p>
                    <p class="text-green">occupied at:    <?php echo e($tenant->created_at); ?></p>
                    <p class="text-green">Amount paid:    <?php echo e($tenant->paid); ?></p>
                    <p class="text-red">Amount balance: <?php echo e($tenant->balance); ?></p>
                    <p><a class="btn btn-warning" href="<?php echo e(route('tenantReport',$tenant->id)); ?>">Generate Tenant Report</a></p>

                </div>
            <div class="box-footer clearfix">
                 <a  href="<?php echo e(route('editTenant',$tenant->id)); ?>" class="btn btn-sm btn-info btn-flat pull-left" type="button" >Edit</a>

                  <a href="<?php echo e(route('refresh',$tenant->id)); ?>" class="btn btn-sm btn-warning btn-flat" type="button">refresh</a>
                  <form action="<?php echo e(route('deleteTenant',$tenant->id)); ?>" method="post">
                    <?php echo method_field('delete'); ?>


                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-sm btn-default btn-flat pull-right">Remove</a>
                  </form>
            </div>
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <!-- /.item -->
            </ul>
          </div>

          <!-- /.box-footer -->
        </div>
        <!-- /.box -->
      </div>

      <div class="col-md-4">

          
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Add users</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">

                
                


              <button type="button" class="btn btn-success" data-toggle="modal" data-target="#modal-success">
               Add Tenant
             </button>
             
             
              
            </div>
            <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Send sms notifications</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body">

                
                

              <button type="button" class="btn btn-success" data-toggle="modal" data-target="#modal-message">
               Send sms
             </button>
             
             
              
            </div>

            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
          
      </div>

</div>
<?php echo $__env->make('landlord.partials.addAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('landlord.partials.addTenantModal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('landlord.partials.messageModal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('landlord.partials.editTenantModal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('landlord.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>