<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();
Route::get('/','TenantController@index')->name('homepage');
Route::get('/houses','HouseController@index')->name('getHouses');
Route::post('/addHouse','HouseController@store')->name('addHouse');
Route::get('/getTenants','TenantController@index')->name('getTenants');
Route::post('/addTenant','TenantController@store')->name('addTenant');
Route::get('/editTenants/{id}','TenantController@edit')->name('editTenant');
Route::delete('/deleteTenant/{id}','TenantController@destroy')->name('deleteTenant');
Route::delete('/deleteHouse/{id}','HouseController@destroy')->name('deleteHouse');
Route::get('/refresh/{id}','TenantController@refresh')->name('refresh');
Route::any('/mpesa/confirm','TransactionController@confirmTransaction');
Route::any('/mpesa/validate','TransactionController@validateTransaction');
Route::get('/testing','TransactionController@createTransaction');
Route::resource('/fabric','fabric');
Route::get('/allTransactions','TransactionController@index')->name('allTransactions');
Route::get('/invoice/{id}','InvoiceController@createInvoice');
Route::get('/home', 'HomeController@index')->name('home');
Route::get('/unpaid_rent','TenantController@show')->name('unpaid');
Route::get('/report','TenantController@generatePDF')->name('report');
Route::get('tenantReport/{id}','TenantController@tenantActivities')->name('tenantReport');
Route::post('sendMessage','TenantController@sendMessage')->name('sendmessage');