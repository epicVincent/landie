
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  </head>
  <body>
        <div class="container">
        
          <div class="">
          <div class="jumbotron">
            <img src="../public/img/logo.png"/>
                <h3 class="text-center">MIMSHACK QUALITY RENTALS</h3>
                <p class="text-center">P.O.BOX 630:50100 NYERI </p>
               <h4 class="text-center">EMAIL:</h4>
               <p class="text-center">info@mimshackrentals.co.ke</p>
               <h4 class="text-center">CALL US ON:</h4>
               <p class="text-center">+254778111112</p>
                
              </div>

         
              <div class="jumbotron">
                <h4 class="text-center">{{ $data['tenant']->username }}</h4>
                <p class="text-center">{{ $data['tenant']->email }}</p>
              </div>

        </div>



         <div class="row">
          <h4 class="text-info text-center">Your payments</h4>
        </div>
          <div class="">
            <table class="table table-striped">
          <thead>
            <tr>

              <th scope="col">Transaction Number</th>
              <th scope="col">Date</th>
              <th scope="col">Amount</th>
              

            </tr>
          </thead>
          <tbody>
            @foreach($data['transactions'] as $transaction)
            <tr>

              <td>{{ $transaction->transaction_number }}</td>
              <td>{{ $transaction->transaction_time }}</td>
              <td>{{ $transaction->amount }}</td>
              
            </tr>
            @endforeach

          </tbody>
            <tr>
              <td></td>
              <td></td>
              <?php
              $total = 0;
              foreach ( $data['transactions'] as $transaction):
                  $total =$total + $transaction->amount;
               endforeach;
              echo "<td>Total Paid:<b>.$total.</b></td>";
              ?>
            </tr>
        </table>


        </div>
    </div>


    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  </body>
</html>
