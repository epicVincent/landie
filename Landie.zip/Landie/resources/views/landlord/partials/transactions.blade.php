@extends('landlord.layout.index')

@section('content')
<div class="row">

  <div class="col-lg-3 col-xs-6">
    <!-- small box -->
    <div class="small-box bg-green">
      <div class="inner">
        <h3>{{ $total_rent_paid }}</h3>

        <p>Total Paid</p>
      </div>
      <div class="icon">
        <i class="ion ion-stats-bars"></i>
      </div>
      {{--  <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>  --}}
    </div>
  </div>

</div>


<div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Hover Data Table</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>Transaction Number</th>
                  <th>Contact</th>

                  <th>Time</th>
                  <th>Amount</th>
                  <th>FirstName</th>
                </tr>
                </thead>
                <tbody>

                </tbody>
                <tfoot>
              @foreach($transactions as $transaction)
              <tr>
                <td>{{ $transaction->transaction_number}}</td>
                <td>{{ $transaction->bill_reference }}</td>
                <td>{{ $transaction->transaction_time}}</td>
                <td>{{ $transaction->amount}}</td>
                <td>{{ $transaction->payer_first_name}}</td>

              </tr>
              @endforeach
              <!-- <tr>
                <th>Rendering engine</th>
                <th>Browser</th>
                <th>Platform(s)</th>
                <th>Engine version</th>
                <th>CSS grade</th>
              </tr> -->
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

@endsection
