<div class="modal modal-success fade" id="modal-message">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Send Sms Notification</h4>
              </div>

              <div class="modal-body">
                <form class="form-horizontal" method="POST" action="{{ route('sendmessage') }}">
                  {{ csrf_field() }}
                <div class="box-body">
                  <div class="form-group">
                    <label for="inputEmail3" class="col-sm-2 control-label">Message</label>

                    <div class="col-sm-10">
                      <textarea type="text" class="form-control" name="message" placeholder="message"></textarea>
                    </div>
                  </div>
                 
                
                  <label from="inputEmail3" class="col-sm-2 control-lable">Room Number</label>
                  <div class="col-sm-10">
                   <select class="form-control" name="contacts[]" placeholder="roomnumber">
                   @foreach($tenants as $tenant)
                        <option value="{{ $tenant->contact }}" multiple="multiple">{{ $tenant->username }}</option>
                      @endforeach

                   </select>
                 </div>
              </div>
                <!-- /.box-body -->


              </div>

                <div class="modal-footer">
                  <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                  <button type="submit" name="submit" class="btn btn-outline">Send Message</button>
                </div>
              </form>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
  </div>
        <!-- /.modal -->
