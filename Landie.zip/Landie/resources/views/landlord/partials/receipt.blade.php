<?php







?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>receipt</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  </head>
  <body>


<div class="panel panel-default">
			  <div class="panel-body">
			  		<div class="row">
                            <div class="col-md-6">
                                <div class="bill-to">
                                    <p class="h5 mb-xs text-dark text-semibold"><strong>Invoiced To:</strong></p>
                                    <address>
                                        Full Name:<br>
                                        HouseNumber:<br>
                                        
                                        Mobile<br>
                                        <strong>Email:</strong> 
                                    </address>
                                </div>
                            </div>
 
                            <div class="col-md-6">
                                <div class="bill-data text-right">
                                    <p class="mb-none">
                                        <span class="text-dark">Invoice Date:</span>
                                        <span class="value"><?php echo date("M d Y"); ?></span>
                                    </p>
                                    <p class="mb-none">
                                        <span class="text-dark">Due Date:</span>
                                        <span class="value"><?php echo date("M d Y"); ?></span>
                                    </p>
                                    
                                 </div>
                            </div>
                        </div>
 
                    <div class="table-responsive">
                        <table class="table invoice-items">
                            <thead>
                            <tr class="h4 text-dark">
                                <th id="cell-id" class="text-semibold">#</th>
                                <th id="cell-item" class="text-semibold">Item</th>
 
                                <th id="cell-price" class="text-center text-semibold">Price</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr id="prodinv"></tr>
								<tr id="prodinv">
                                    <td>ID</td>
                                    <td class="text-semibold text-dark">Product/Service Name</td>
                                    <td class="text-center amount">Ksh 3000.00</td>
                                </tr>
                              
                            
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="row">
                    	<div class="col-sm-4">
                    		
                    	</div>
                    	<div class="col-md-4">
                    		 <h2> Invoice Total: <span class="amount">Ksh. 3000.00</span> </h2>
                    	</div>
                    	<div class="col-md-4">
                    		Amount Paid By : 
					  		<select name="paymentmode" class="form-control">
							  <option value="cash">Cash</option>
							  <option value="card">M-pesa</option>
							</select>
                    	</div>
                    </div>
                   
			  </div>
    </div>
</body>
</html>