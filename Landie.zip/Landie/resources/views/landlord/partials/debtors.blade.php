@extends('landlord.layout.index')


@section('content')
<div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Tenants with rent arrears</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>Tenant Name</th>
                  <th>Amount Paid</th>
                  <th>Remaining Balance</th>
                  <th>Month last paid</th>

                </tr>
                </thead>
                <tbody>

                </tbody>
                <tfoot>

                @foreach($defaulters as $defaulter)
              <tr>

                <td>{{ $defaulter->username}}</td>
                <td>{{ $defaulter->paid }}</td>
                <td>{{ $defaulter->balance }}</td>
                <td>{{ \Carbon\Carbon::parse($defaulter->updated_at)->format('d/m/Y')}}</td>
                

              </tr>
              @endforeach
              <!-- <tr>
                <th>Rendering engine</th>
                <th>Browser</th>
                <th>Platform(s)</th>
                <th>Engine version</th>
                <th>CSS grade</th>
              </tr> -->
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

@endsection
