@extends('landlord.layout.index')

@section('content')
<div class="container">

  <div class="row">
    <div class="col-md-6">
         <!-- general form elements -->
         <div class="box box-primary">
           <div class="box-header with-border">
             <h3 class="box-title">Quick Example</h3>
           </div>

                    <form class="form-horizontal" method="POST" action="{{ route('addTenant') }}">
                      {{ csrf_field() }}
                    <div class="box-body">
                      <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">Username</label>

                        <div class="col-sm-10">
                          <input type="text" class="form-control" name="username" id="inputEmail3" value="{{ old($tenant->username) }}" >
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">Email</label>

                        <div class="col-sm-10">
                          <input type="email" class="form-control" id="inputEmail3" name="email" placeholder="Email" value="{{ old('$tenant->email') }}">
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">Contact</label>

                        <div class="col-sm-10">
                          <input type="contact" class="form-control" id="inputEmail3" name="contact" placeholder="Phone Number" value="{{old('$tenant->contact') }}">
                        </div>
                      </div>
                      <label from="inputEmail3" class="col-sm-2 control-lable">Room Number</label>
                      <div class="col-sm-10">
                       <select class="form-control" name="roomnumber" placeholder="roomnumber">
                         @foreach($rooms as $room)
                            <option value="{{ $room->id }}" >{{ $room->number }}</option>
                          @endforeach

                       </select>
                     </div>
                  </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                      <button  type="submit" name="submit" class="btn btn-success">Save changes</button>
                    </div>
                  </form>
                </div>
              </div>

  </div>
</div>

@endsection
