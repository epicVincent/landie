@extends('landlord.layout.index')

@section('content')

@endsection
