-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 12, 2018 at 02:55 PM
-- Server version: 5.7.24-0ubuntu0.16.04.1
-- PHP Version: 7.0.32-4+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `landie`
--

-- --------------------------------------------------------

--
-- Table structure for table `houses`
--

CREATE TABLE `houses` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rent` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `housetype` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `houses`
--

INSERT INTO `houses` (`id`, `title`, `number`, `rent`, `created_at`, `updated_at`, `housetype`) VALUES
(1, 'dsaf', 'rw', 234, '2018-10-04 17:25:03', '2018-10-04 17:25:03', 'dfsa'),
(2, 'Mess', '23k', 50000, '2018-10-09 06:34:39', '2018-10-09 06:34:39', 'Dining');

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` int(10) UNSIGNED NOT NULL,
  `tenant_id` int(10) UNSIGNED NOT NULL,
  `amount` double NOT NULL,
  `transaction_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `paid_by` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_10_04_163549_create_transactions_table', 1),
(4, '2018_10_04_163559_create_houses_table', 1),
(5, '2018_10_04_163608_create_tenants_table', 1),
(6, '2018_10_04_201108_add_housetype_to_houses', 1),
(7, '2018_10_12_105048_create_invoices_table', 2),
(8, '2018_10_12_191819_create_payments_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(10) UNSIGNED NOT NULL,
  `tenant_id` int(10) UNSIGNED NOT NULL,
  `transaction_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tenants`
--

CREATE TABLE `tenants` (
  `id` int(10) UNSIGNED NOT NULL,
  `house_id` int(10) UNSIGNED NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `paid` double NOT NULL DEFAULT '0',
  `balance` double NOT NULL DEFAULT '0',
  `expected_total` double NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tenants`
--

INSERT INTO `tenants` (`id`, `house_id`, `username`, `contact`, `email`, `paid`, `balance`, `expected_total`, `created_at`, `updated_at`) VALUES
(3, 1, 'VIncent Kamau', '+254773208943', 'kamau@gmail.com', 0, 234, 0, '2018-10-09 06:34:08', '2018-10-09 06:34:12'),
(5, 2, 'dedan Kimathi', '0719546525', 'builder@gmail.com', 367392, -317392, 0, '2018-10-09 06:35:19', '2018-11-06 09:31:08'),
(6, 1, 'Maggie', '07435678', 'maggie@gmail.com', 0, 234, 0, '2018-10-16 06:12:14', '2018-11-06 09:31:04');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(10) UNSIGNED NOT NULL,
  `tenant_id` int(10) UNSIGNED NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `transaction_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_time` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double(8,2) NOT NULL,
  `short_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bill_reference` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payer_first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payer_middle_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payer_last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `tenant_id`, `status`, `transaction_number`, `transaction_time`, `amount`, `short_code`, `bill_reference`, `mobile_number`, `payer_first_name`, `payer_middle_name`, `payer_last_name`, `created_at`, `updated_at`) VALUES
(1, 0, 1, 'MJ581H6WR0', '2018-10-05 01:57:41', 3001.00, '603059', '254708374149', '254708374149', 'John', 'J.', 'Doe', '2018-10-04 19:58:06', '2018-10-04 19:58:06'),
(2, 0, 1, 'MJ541H6WV2', '2018-10-05 10:19:40', 23532.00, '603059', '254708374149', '254708374149', 'John', 'J.', 'Doe', '2018-10-05 04:20:05', '2018-10-05 04:20:05'),
(3, 0, 1, 'MJ531H6WVB', '2018-10-05 10:29:52', 2332.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-05 04:30:11', '2018-10-05 04:30:11'),
(4, 0, 1, 'MJ991H6YHJ', '2018-10-09 12:26:17', 32.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-09 06:27:27', '2018-10-09 06:27:27'),
(5, 0, 1, 'MJ921H6YHM', '2018-10-09 12:31:58', 32.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-09 06:32:27', '2018-10-09 06:32:27'),
(6, 0, 1, 'MJ931H6YHX', '2018-10-09 13:00:25', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-09 07:00:57', '2018-10-09 07:00:57'),
(7, 0, 1, 'MJC41H6ZE6', '2018-10-12 12:23:24', 234.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-12 06:23:53', '2018-10-12 06:23:53'),
(8, 0, 1, 'MJE81H7026', '2018-10-14 14:06:29', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-14 08:07:05', '2018-10-14 08:07:05'),
(9, 5, 1, 'MJE81H702G', '2018-10-14 14:19:54', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-14 08:21:07', '2018-10-14 08:21:07'),
(10, 5, 1, 'MJE91H702H', '2018-10-14 14:20:43', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-14 08:21:22', '2018-10-14 08:21:22'),
(11, 5, 1, 'MJE01H702I', '2018-10-14 14:21:34', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-14 08:22:10', '2018-10-14 08:22:10'),
(12, 5, 1, 'MJE41H702M', '2018-10-14 14:27:51', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-14 08:28:23', '2018-10-14 08:28:23'),
(13, 5, 1, 'MJE81H7044', '2018-10-14 18:57:32', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-14 12:58:06', '2018-10-14 12:58:06'),
(14, 5, 1, 'MJE91H7045', '2018-10-14 18:58:46', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-14 12:59:19', '2018-10-14 12:59:19'),
(15, 5, 1, 'MJE61H704C', '2018-10-14 19:04:10', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-14 13:04:41', '2018-10-14 13:04:41'),
(16, 5, 1, 'MJE51H704B', '2018-10-14 19:03:32', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-14 13:04:42', '2018-10-14 13:04:42'),
(17, 5, 1, 'MJE71H704D', '2018-10-14 19:04:44', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-14 13:05:15', '2018-10-14 13:05:15'),
(18, 5, 1, 'MJE21H704I', '2018-10-14 19:07:11', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-14 13:07:41', '2018-10-14 13:07:41'),
(19, 5, 1, 'MJE11H704H', '2018-10-14 19:06:35', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-14 13:07:44', '2018-10-14 13:07:44'),
(20, 5, 1, 'MJE31H704J', '2018-10-14 19:08:29', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-14 13:09:03', '2018-10-14 13:09:03'),
(21, 5, 1, 'MJE41H704K', '2018-10-14 19:09:20', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-14 13:09:53', '2018-10-14 13:09:53'),
(22, 5, 1, 'MJE51H704L', '2018-10-14 19:09:58', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-14 13:10:36', '2018-10-14 13:10:36'),
(23, 5, 1, 'MJE51H704L', '2018-10-14 19:09:58', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-14 13:10:53', '2018-10-14 13:10:53'),
(24, 5, 1, 'MJE61H704M', '2018-10-14 19:10:45', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-14 13:11:18', '2018-10-14 13:11:18'),
(25, 5, 1, 'MJF71H70EX', '2018-10-15 14:34:29', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-15 08:35:54', '2018-10-15 08:35:54'),
(26, 5, 1, 'MJF81H70EY', '2018-10-15 14:35:50', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-15 08:36:34', '2018-10-15 08:36:34'),
(27, 5, 1, 'MJF81H70EY', '2018-10-15 14:35:50', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-15 08:36:57', '2018-10-15 08:36:57'),
(28, 5, 1, 'MJF81H70EY', '2018-10-15 14:35:50', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-15 08:37:20', '2018-10-15 08:37:20'),
(29, 5, 1, 'MJF61H70F6', '2018-10-15 15:04:33', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-15 09:05:21', '2018-10-15 09:05:21'),
(30, 5, 1, 'MJF61H70F6', '2018-10-15 15:04:33', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-15 09:05:43', '2018-10-15 09:05:43'),
(31, 5, 1, 'MJF61H70F6', '2018-10-15 15:04:33', 7654.00, '603059', '0719546525', '254708374149', 'John', 'J.', 'Doe', '2018-10-15 09:06:02', '2018-10-15 09:06:02');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Allan Maina', 'allancodes@gmail.com', NULL, '$2y$10$XM8BTowo9h25J3E0Epxt4OHE8Plbx7Fo2g1wy0HMQr104WUjFj7ZG', 'JZ6wcf2aTjSQfXBpajh2su4aKCFI8qmasOQeeFNV3ZT2PIkQWYtVxvAnxcwm', '2018-10-05 01:46:43', '2018-10-05 01:46:43'),
(2, 'bonnie kuria', 'bonnie@gmail.com', NULL, '$2y$10$zh5U2z1GDVvNYqzq4Brf2OFZq9sSzNQRu6iw2WpnQWgQv5EfFH4RS', NULL, '2018-10-09 05:54:45', '2018-10-09 05:54:45'),
(3, 'Man Kush', 'kush@gmail.com', NULL, '$2y$10$VZO5E5wjeR0grx/bFOlm4er5MKxWs7Vpi1RUcUkyVyWHThNeUsq0y', NULL, '2018-11-06 09:15:25', '2018-11-06 09:15:25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `houses`
--
ALTER TABLE `houses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoices_tenant_id_index` (`tenant_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payments_tenant_id_index` (`tenant_id`);

--
-- Indexes for table `tenants`
--
ALTER TABLE `tenants`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tenants_house_id_index` (`house_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `houses`
--
ALTER TABLE `houses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tenants`
--
ALTER TABLE `tenants`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`);

--
-- Constraints for table `tenants`
--
ALTER TABLE `tenants`
  ADD CONSTRAINT `tenants_house_id_foreign` FOREIGN KEY (`house_id`) REFERENCES `houses` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
